export default function AccountingPage () {
    return (
        <div>待完成</div>
    )
}