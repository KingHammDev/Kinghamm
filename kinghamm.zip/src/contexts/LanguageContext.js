'use client'

import { createContext, useContext, useState, useEffect } from 'react'

const LanguageContext = createContext(undefined)

export function LanguageProvider({ children }) {
    const [currentLanguage, setCurrentLanguage] = useState('en')
    const [translations, setTranslations] = useState({})

    useEffect(() => {
        // 從 localStorage 讀取使用者之前選擇的語言
        const savedLanguage = localStorage.getItem('userLanguage')
        if (savedLanguage) {
            setCurrentLanguage(savedLanguage)
        }
    }, [])

    const setLanguage = async (lang) => {
        try {
            // 動態引入語言檔
            const newTranslations = await import(`../locales/${lang}.json`)
            setTranslations(newTranslations.default)
            setCurrentLanguage(lang)
            // 儲存使用者的語言選擇
            localStorage.setItem('userLanguage', lang)
        } catch (error) {
            console.error('Failed to load language file:', error)
        }
    }

    return (
        <LanguageContext.Provider value={{ currentLanguage, setLanguage, translations }}>
            {children}
        </LanguageContext.Provider>
    )
}

export const useLanguage = () => {
    const context = useContext(LanguageContext)
    if (context === undefined) {
        throw new Error('useLanguage must be used within a LanguageProvider')
    }
    return context
}